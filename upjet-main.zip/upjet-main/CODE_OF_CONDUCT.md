## Code of Conduct

Upjet is under [the Apache 2.0 license](LICENSE) with [notice](NOTICE).