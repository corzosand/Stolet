// Package version contains the version of upjet repo
package version

// Version will be overridden with the current version at build time using the -X linker flag
var Version = "0.0.0"
